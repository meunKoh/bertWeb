package com.gnew;

import java.io.File;  
import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.Iterator;   
import java.util.List;  
import javax.servlet.ServletException;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Util {

	public Util() {		
 	}
	
	public static String runPy(String command){
		String strCmd = "python C:\\Users\\kkk\\PycharmProjects\\hug-face\\hug\\inference.py " + command;
		//String strCmd = "python C:\\Users\\kkk\\PycharmProjects\\hug-face\\hug\\inference.py";
		String strInput = "";
		String strRtn = "";

        try {
            // print a message
            //System.out.println("Executing python code"); 
            Process process = Runtime.getRuntime().exec(strCmd);
            
            BufferedReader stdInput = new BufferedReader(new 
                 InputStreamReader(process.getInputStream()));

            BufferedReader stdError = new BufferedReader(new 
                 InputStreamReader(process.getErrorStream()));

            // read the output from the command
            //System.out.println("python should be run.");
            while ((strInput = stdInput.readLine()) != null) {
            	System.out.println(strInput);
                strRtn = strInput;
            }
            
            //System.out.println("Here is the standard error of the command (if any):\n");
            while ((strInput = stdError.readLine()) != null) {
            	System.out.println(strInput);
            	strRtn = strInput;
            }
            
            //System.exit(0);
            return strRtn;
        }
        catch (IOException e) {
            e.printStackTrace();
            //System.exit(-1);
            return strRtn;
        }
    }

	public static void main(String[] args) throws IOException, InterruptedException {
		
		//System.out.println(exec("python.exe C:\\Users\\kkk\\PycharmProjects\\hug-face\\hug\\inference.py"));
		System.out.println("END");

		runPy("aaa");
	}

}
