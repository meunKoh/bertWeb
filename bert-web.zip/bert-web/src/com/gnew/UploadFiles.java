package com.gnew;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


/**
 * Servlet implementation class UploadFiles
 */
@WebServlet("/upload.do")
public class UploadFiles extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadFiles() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		String UPLOAD_DIR = "C:\\Users\\kkk\\eclipse-workspace\\bert-web\\temp/";

		// ������ ���� ���
		//String applicationPath = request.getServletContext().getRealPath("");
		
		String uploadFilePath = UPLOAD_DIR;
		ArrayList<String> filepaths = new ArrayList<String>();
		ArrayList<String> filenames = new ArrayList<String>();
		ArrayList<String> predictions = new ArrayList<String>();
		
		String filePath = null;
		String fileName = null;
		String prediction = null;
		
		for(Part part : request.getParts()) {
			
			fileName = part.getSubmittedFileName();
			filePath = uploadFilePath + fileName;
			
			File convFile = new File(filePath);
			convFile.createNewFile();
			part.write(filePath); 
			filepaths.add(filePath);
			
			prediction = GetClassifier.runPy(filePath);
			predictions.add(prediction);
			
		}
		
		
		request.setAttribute("files", filenames);
		request.setAttribute("predictions", predictions);
		
		RequestDispatcher disp = request.getRequestDispatcher("/Main.jsp");
		disp.forward(request, response);
	}
}
